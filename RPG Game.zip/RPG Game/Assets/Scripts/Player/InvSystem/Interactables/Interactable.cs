using UnityEngine;
using UnityEngine.AI;

/*	
	This is for all objects that the player can
	interact with such as enemies, items etc. It is to be used as a base class.
*/

[RequireComponent(typeof(ColorOnHover))]
public class Interactable : MonoBehaviour {

	public float radius = 3f;
	public Transform interactionTransform;

	bool isFocus = false;	
	Transform player;		

	bool hasInteracted = false;	

	void Update ()
	{
		if (isFocus)	// If currently being focused
		{
			float distance = Vector3.Distance(player.position, interactionTransform.position);
		
			if (!hasInteracted && distance <= radius)
			{
				// Interact with the object
				hasInteracted = true;
				Interact();
			}
		}
	}

	// Called when the object is being focused
	public void OnFocused (Transform playerTransform)
	{
		isFocus = true;
		hasInteracted = false;
		player = playerTransform;
    }

	// Called when the object is no longer focused
	public void OnDefocused ()
	{
		isFocus = false;
		hasInteracted = false;
		player = null;
	}

	// yo be overwritten
	public virtual void Interact ()
	{
		
	}

	void OnDrawGizmosSelected ()
	{
		Gizmos.color = Color.yellow;
		Gizmos.DrawWireSphere(interactionTransform.position, radius);
	}

}
