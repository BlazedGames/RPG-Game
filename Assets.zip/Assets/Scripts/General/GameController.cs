﻿using System.Collections;
using UnityEngine;

    public class GameController : MonoBehaviour
    {

        public static float NormalizedTime { get; set; }
    }

